local L = LibStub("AceLocale-2.2"):new("ZOMGBuffs")

L:RegisterTranslations("esES", function() return
--[===[@debug@
{
}
--@end-debug@]===]
{
	Actions = "Acciones",
	["Adjust height of the bars"] = "Ajustar altura de las barras",
	["Adjust the size of the timer text"] = "Ajustar el tamaño del texto del tiempo",
	Alphabetical = "Alfabético",
	["<new name>"] = "<nuevo nombre>",
	[" on %s"] = " en %s",
	["%s blacklisted for 10 seconds"] = "%s en la lista negra durante 10 segundos",
	["%s%s%s|r to cast %s%s|r%s"] = "%s%s%s|r para castear %s%s|r%s",
	["<template name>"] = "<nombre de plantilla>",
}

end)
