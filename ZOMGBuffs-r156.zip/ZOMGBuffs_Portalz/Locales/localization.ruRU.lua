﻿local L = LibStub("AceLocale-2.2"):new("ZOMGPortalz")

L:RegisterTranslations("ruRU", function() return
--[===[@debug@
{
}
--@end-debug@]===]
{
}

end)
