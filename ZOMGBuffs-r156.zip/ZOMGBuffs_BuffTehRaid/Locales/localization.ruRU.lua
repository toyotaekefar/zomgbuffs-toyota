local L = LibStub("AceLocale-2.2"):new("ZOMGBuffTehRaid")

L:RegisterTranslations("ruRU", function() return
--[===[@debug@
{
}
--@end-debug@]===]
{
}

end)
