﻿local L = LibStub("AceLocale-2.2"):new("ZOMGLog")

L:RegisterTranslations("esES", function() return
--[===[@debug@
{
}
--@end-debug@]===]
{
}

end)
