﻿local L = LibStub("AceLocale-2.2"):new("ZOMGLog")

L:RegisterTranslations("ruRU", function() return
--[===[@debug@
{
}
--@end-debug@]===]
{
}

end)
