local L = LibStub("AceLocale-2.2"):new("ZOMGSelfBuffs")

L:RegisterTranslations("koKR", function() return
--[===[@debug@
{
}
--@end-debug@]===]
{
	["Template configuration"] = "템플릿 설정",
	Templates = "템플릿",
	Tracking = "트래킹",
	["Tracking configuration"] = "트래킹 설정",
	["Use this item or spell on the main hand weapon"] = "이 아이템이나 주문을 주무기 슬롯에 사용합니다.",
	["Use this item or spell on the off hand weapon"] = "이 아이템이나 주문을 보조무기 슬롯에 사용합니다.",
}

end)
