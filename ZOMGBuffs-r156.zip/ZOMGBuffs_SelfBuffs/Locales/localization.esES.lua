local L = LibStub("AceLocale-2.2"):new("ZOMGSelfBuffs")

L:RegisterTranslations("esES", function() return
--[===[@debug@
{
}
--@end-debug@]===]
{
}

end)
