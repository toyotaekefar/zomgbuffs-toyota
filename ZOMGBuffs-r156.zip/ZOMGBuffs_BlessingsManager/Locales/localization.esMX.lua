﻿local L = LibStub("AceLocale-2.2"):new("ZOMGBlessingsManager")

L:RegisterTranslations("esMX", function() return
--[===[@debug@
{
}
--@end-debug@]===]
{
}

end)
